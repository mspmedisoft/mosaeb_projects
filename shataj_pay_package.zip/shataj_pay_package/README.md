A well-organized Package used for completing any form of payment transaction.

N\B: All the buttons of this package is only focused on TEXT-Buttons, not on ICON-Buttons


The key components of this package are:
- **Core SDK Logic** 
- (`shataj_pay_client.dart`, `shataj_pay_controller.dart`)
- **Configuration & Error Handling** 
- (`shataj_pay_config.dart`, `shataj_pay_exceptions.dart`)
- **Models** 
- (`payment_request.dart`, `payment_response.dart`, `transaction_status.dart`)
- **Services** 
- (`api_service.dart`, `encryption_service.dart`)
- **UI Components** 
- (`payment_screen.dart`, `webview_screen.dart`)
- **Platform-Specific Integration** 
- (`platform_channel.dart`)

## Features

TODO: List what your package can do. Maybe include images, gifs, or videos.

## Getting started

TODO: List prerequisites and point out 
the information about how to start using the package.

## Usage

TODO: Include short and useful examples for package users. 
Add longer examples to `/example` folder.

```dart
final number = +8801733919791;
```

## Additional information

TODO: Tell users more about the package: 
what response they can expect from the package authors?,
how to contribute to the package?,
where to find more information?,
how to file issues?,
and more...