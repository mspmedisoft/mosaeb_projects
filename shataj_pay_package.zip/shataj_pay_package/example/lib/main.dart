// import 'package:flutter_payment_gateway/flutter_payment_gateway.dart';
//
// void main() async {
//   ShatajPayButton(
//     amount: 100,
//     merchantInvoiceNumber: "INV123",
//     onSuccess: (response) => print("Payment Successful!"),
//   );
// }
