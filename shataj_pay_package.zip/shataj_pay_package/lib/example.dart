import 'package:flutter_payment_gateway/flutter_payment_gateway.dart';

void main() async {
  PaymentGateway paymentGateway = PaymentGateway();
  await paymentGateway.initiatePayment('100.00');
}