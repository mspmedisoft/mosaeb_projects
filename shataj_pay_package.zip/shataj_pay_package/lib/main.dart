import 'package:flutter/material.dart';
import 'package:shataj_pay_package/src/shataj_pay_view.dart';
import 'package:shataj_pay_package/src/theme/theme.dart';

void main() {
  runApp(const ShatajPayApp());
}

class ShatajPayApp extends StatelessWidget {
  const ShatajPayApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Hide debug banner
      title: "Shataj Pay",
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system, // Auto-switch between dark/light mode
      home: PaymentScreen(), // Start with PaymentScreen
    );
  }
}

/// Define a screen that initializes payments
class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key});

  final String paymentUrl = "https://shatajpay.com/initiate";

  void onPaymentSuccess(String response) {
    SnackBar(content: Text("Payment Success: $response"));
  }

  void onPaymentFailure(String response) {
    SnackBar(content: Text("Payment Failed: $response"));
  }

  void onPaymentCancel() {
    SnackBar(content: Text("Payment has been Cancelled"));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Shataj Pay")),
      body: Center(
        child: ElevatedButton(
          child: Text("Pay Now"),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder:
                    (context) => ShatajPayView(
                      shatajPayURL: null,
                      paymentUrl: paymentUrl,
                      onPaymentSuccess: onPaymentSuccess,
                      onPaymentFailure: onPaymentFailure,
                      onPaymentCancel: onPaymentCancel,
                    ),
              ),
            );
          },
        ),
      ),
    );
  }
}
