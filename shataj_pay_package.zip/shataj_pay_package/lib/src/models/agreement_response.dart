class CreateAgreementResponseModel {
  final String agreementId;
  final String status;
  final String message;

  CreateAgreementResponseModel({
    required this.agreementId,
    required this.status,
    required this.message,
  });

  factory CreateAgreementResponseModel.fromJson(Map<String, dynamic> json) {
    return CreateAgreementResponseModel(
      agreementId: json['agreement_id'],
      status: json['status'],
      message: json['message'],
    );
  }
}

class PayWithAgreementExecuteResponseModel {
  final String paymentId;
  final String status;
  final String message;

  PayWithAgreementExecuteResponseModel({
    required this.paymentId,
    required this.status,
    required this.message,
  });

  factory PayWithAgreementExecuteResponseModel.fromJson(
    Map<String, dynamic> json,
  ) {
    return PayWithAgreementExecuteResponseModel(
      paymentId: json['payment_id'],
      status: json['status'],
      message: json['message'],
    );
  }
}
