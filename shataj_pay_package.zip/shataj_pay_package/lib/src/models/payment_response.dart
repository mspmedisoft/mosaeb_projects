class PaymentResponse {
  final String transactionId;
  final bool isSuccess;

  PaymentResponse({required this.transactionId, 
  required this.isSuccess});

  factory PaymentResponse.fromJson(Map<String, dynamic> json) {
    return PaymentResponse(
      transactionId: json['transactionId'],
      isSuccess: json['isSuccess'],
    );
  }
}