import 'dart:developer';

class ShatajPayResponse {
  final String trxId;
  final String payerReference;
  final String paymentId;
  final String customerMsisdn;
  final String merchantInvoiceNumber;
  final String _executeTime;

  ShatajPayResponse(
    this._executeTime, {
    required this.trxId,
    required this.payerReference,
    required this.paymentId,
    required this.customerMsisdn,
    required this.merchantInvoiceNumber,
  });

  DateTime get executeTime {
    try {
      return DateTime.parse(_executeTime.replaceAll(" GMT+0600", ""));
    } catch (e, st) {
      log("DateTime parse Error", error: e, stackTrace: st);
      return DateTime.now();
    }
  }

  @override
  String toString() {
    return 'ShatajPayResponse(trxId: $trxId, '
        'payerReference: $payerReference, '
        'paymentId: $paymentId, '
        'customerMsisdn: $customerMsisdn, '
        'merchantInvoiceNumber: $merchantInvoiceNumber, '
        '_executeTime: $_executeTime)';
  }
}
