enum ShatajPayStatus { success, failure, cancelled }

extension ShatajPayStatusExtension on ShatajPayStatus {
  String get message {
    switch (this) {
      case ShatajPayStatus.success:
        return "Payment successful.";
      case ShatajPayStatus.failure:
        return "Payment failed. Please try again.";
      case ShatajPayStatus.cancelled:
        return "Payment was cancelled by the user.";
    }
  }
}
