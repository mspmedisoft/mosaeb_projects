import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shataj_pay_package/src/utils/error_handler.dart';
import 'models/payment_status.dart';

class ShatajPayGateway {
  final String baseUrl;
  final String apiKey;

  ShatajPayGateway({required this.baseUrl, required this.apiKey});

  Future<Map<String, dynamic>> initiatePayment(
    double amount,
    String currency,
  ) async {
    final url = Uri.parse('$baseUrl/payment/initiate');
    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({'amount': amount, 'currency': currency}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw ShatajPayError('Failed to initiate payment');
    }
  }

  Future<ShatajPayStatus> checkPaymentStatus(String transactionId) async {
    final url = Uri.parse('$baseUrl/payment/status/$transactionId');
    final response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $apiKey'},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      switch (data['status']) {
        case 'success':
          return ShatajPayStatus.success;
        case 'failed':
          return ShatajPayStatus.failure;
        case 'cancelled':
          return ShatajPayStatus.cancelled;
        default:
          throw ShatajPayError('Unknown payment status');
      }
    } else {
      throw ShatajPayError('Failed to check payment status');
    }
  }
}
