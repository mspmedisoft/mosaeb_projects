import 'package:flutter/services.dart';

class PlatformChannel {
  static const MethodChannel _channel = MethodChannel('com.shataj.pay');

  // Method to initiate payment
  Future<String?> initiatePayment(String amount) async {
    try {
      final String? result = await _channel.invokeMethod('startPayment', {
        'amount': amount,
      });
      return result;
    } on PlatformException catch (e) {
      print("Error initiating payment: ${e.message}");
      return null;
    }
  }

  // You can add more methods
  // for other platform-specific functionality
  // like payment callbacks
}
