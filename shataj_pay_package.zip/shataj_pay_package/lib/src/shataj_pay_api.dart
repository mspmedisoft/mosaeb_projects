import 'package:fpdart/fpdart.dart';
import 'package:shataj_pay_package/src/utils/token_service.dart';
import 'package:shataj_pay_package/src/shataj_pay_credentials.dart';
import 'package:shataj_pay_package/src/utils/error_handler.dart';
import 'models/agreement_response.dart';
import 'models/token_response.dart';

class ShatajPayApi {
  final TokenApi _tokenApi;

  ShatajPayApi({required ShatajPayCredentials shatajPayCredentials})
    : _tokenApi = TokenApi(shatajPayCredentials, shatajPayCredentials.appKey);

  // Token related
  Future<Either<ShatajPayError, TokenResponseModel>> createToken() async {
    return await _tokenApi.createToken();
  }

  Future<Either<ShatajPayError, TokenResponseModel>> refreshToken({
    required String refreshToken,
  }) async {
    return await _tokenApi.refreshToken(refreshToken: refreshToken);
  }

  // Create agreement API
  Future<Either<ShatajPayError, CreateAgreementResponseModel>>
  payWithAgreement({
    required String idToken,
    required String amount,
    required String agreementId,
    required String merchantInvoiceNumber,
  }) async {
    return await _tokenApi.payWithAgreement(
      idToken: idToken,
      amount: amount,
      agreementId: agreementId,
      merchantInvoiceNumber: merchantInvoiceNumber,
    );
  }

  Future<Either<ShatajPayError, PayWithAgreementExecuteResponseModel>>
  executePayWithAgreement({
    required String paymentId,
    required String idToken,
  }) async {
    return await _tokenApi.executePayWithAgreement(
      paymentId: paymentId,
      idToken: idToken,
    );
  }
}
