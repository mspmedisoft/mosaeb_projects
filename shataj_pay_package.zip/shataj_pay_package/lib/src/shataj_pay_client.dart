import 'package:flutter/material.dart';
import 'package:shataj_pay_package/src/shataj_pay_credentials.dart';
import 'models/payment_response.dart';

class ShatajPay {
  ShatajPay({ShatajPayCredentials? shatajPayCredentials});

  Future<ShatajPayResponse> processPayment({
    required BuildContext context,
    required double amount,
    required String merchantInvoiceNumber,
    String payerReference = " ",
  }) async {
    // Implement payment processing logic here
    throw UnimplementedError();
  }
}
