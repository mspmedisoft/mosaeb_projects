import 'package:flutter/material.dart';
import 'package:shataj_pay_package/src/shataj_pay_view.dart';
import 'models/payment_status.dart';

class ShatajPayController {
  final String baseUrl;
  final Function(ShatajPayStatus, String) onPaymentResult;

  ShatajPayController({required this.baseUrl, required this.onPaymentResult});

  void startPayment(BuildContext context, String transactionId) {
    String paymentUrl = "$baseUrl/checkout?transaction_id=$transactionId";

    Navigator.push(
      context,
      MaterialPageRoute(
        builder:
            (context) => ShatajPayView(
              paymentUrl: paymentUrl,
              shatajPayURL: null,
              onPaymentSuccess: (response) {
                onPaymentResult(ShatajPayStatus.success, response);
              },
              onPaymentFailure: (response) {
                onPaymentResult(ShatajPayStatus.failure, response);
              },
              onPaymentCancel: () {
                onPaymentResult(
                  ShatajPayStatus.cancelled,
                  "Payment has been Cancelled",
                );
              },
            ),
      ),
    );
  }
}
