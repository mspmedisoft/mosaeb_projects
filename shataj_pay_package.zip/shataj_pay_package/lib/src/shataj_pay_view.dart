import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class ShatajPayView extends StatefulWidget {
  final String paymentUrl;
  final Function(String) onPaymentSuccess;
  final Function(String) onPaymentFailure;
  final Function() onPaymentCancel;

  const ShatajPayView({
    super.key,
    required this.paymentUrl,
    required this.onPaymentSuccess,
    required this.onPaymentFailure,
    required this.onPaymentCancel,
    required shatajPayURL,
  });

  @override
  _ShatajPayViewState createState() => _ShatajPayViewState();
}

class _ShatajPayViewState extends State<ShatajPayView> {
  late WebViewController _controller;

  @override
  void initState() {
    /// Initiation of WebView functionality
    super.initState();
    _controller =
        WebViewController()
          ..setJavaScriptMode(JavaScriptMode.unrestricted)
          ..setNavigationDelegate(
            NavigationDelegate(
              onPageFinished: (String url) {
                if (url.contains("success")) {
                  widget.onPaymentSuccess(url);
                } else if (url.contains("failure")) {
                  widget.onPaymentFailure(url);
                } else if (url.contains("cancel")) {
                  widget.onPaymentCancel();
                }
              },
            ),
          )
          ..loadRequest(Uri.parse(widget.paymentUrl));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text("Shataj Pay")),
        leading: TextButton(
          child: const Text('CANCEL'),
          onPressed: () {
            widget.onPaymentCancel();
            Navigator.pop(context);
          },
        ),
      ),
      backgroundColor:
          Theme.of(
            context,
          ).scaffoldBackgroundColor, // Allow theme customization
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}
