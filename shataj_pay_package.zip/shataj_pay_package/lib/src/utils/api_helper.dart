import 'dart:convert';
import 'dart:io';
import 'package:fpdart/fpdart.dart';
import 'package:http/http.dart';
import 'package:shataj_pay_package/src/utils/error_handler.dart';

mixin ApiHelper {
  Future<Either<ShatajPayError, Map<String, dynamic>>> networkCallHelper({
    required Future<Response> Function() function,
  }) async {
    try {
      final response = await function.call();

      switch (response.statusCode) {
        case 200:
          return right(json.decode(response.body) as Map<String, dynamic>);
        case 400:
          return left(ShatajPayError("Bad Request"));
        case 401:
          return left(ShatajPayError("Unauthorized Access"));
        case 403:
          return left(ShatajPayError("Forbidden"));
        case 404:
          return left(ShatajPayError("Not Found"));
        case 500:
          return left(ShatajPayError("Internal Server Error"));
        default:
          return left(ShatajPayError("Unknow Error occurred"));
      }
    } on SocketException catch (e) {
      return left(ShatajPayError(e.message));
    }
  }
}
