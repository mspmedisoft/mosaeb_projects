import 'dart:developer';

class ShatajPayError implements Exception {
  final String message;
  ShatajPayError(this.message);

  @override
  String toString() => 'ShatajPayError: $message';
}
