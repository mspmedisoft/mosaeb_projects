import 'dart:developer' as dev;

class Logger {
  static void logInfo(String message) {
    dev.log(message, name: 'ShatajPay - INFO');
  }

  static void logError(
    String message, [
    dynamic error,
    StackTrace? stackTrace,
  ]) {
    dev.log(
      message,
      name: 'ShatajPay - ERROR',
      error: error,
      stackTrace: stackTrace,
    );
  }
}
