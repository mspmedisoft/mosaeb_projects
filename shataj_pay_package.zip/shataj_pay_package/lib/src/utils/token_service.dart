import 'dart:convert';
import 'package:fpdart/fpdart.dart';
import 'package:http/http.dart' as http;
import 'package:shataj_pay_package/src/models/agreement_response.dart';
import 'package:shataj_pay_package/src/shataj_pay_credentials.dart';
import 'package:shataj_pay_package/src/utils/error_handler.dart';
import '../models/token_response.dart';
import 'api_helper.dart';

class TokenApi with ApiHelper {
  final ShatajPayCredentials shatajPayCredentials;
  final String apiKey;
  late String _baseUrl;

  TokenApi(this.shatajPayCredentials, this.apiKey) {
    _baseUrl =
        "https://tokenized.${shatajPayCredentials.isSandbox ? "sandbox" : "pay"}.shataj.pay/v1.2.0-beta";
  }

  Future<Either<ShatajPayError, TokenResponseModel>> refreshToken({
    required String refreshToken,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/token/refresh'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $refreshToken',
        },
        body: jsonEncode({'refresh_token': refreshToken}),
      );

      if (response.statusCode == 200) {
        return Right(TokenResponseModel.fromJson(jsonDecode(response.body)));
      } else {
        return Left(ShatajPayError('Failed to refresh token'));
      }
    } catch (e) {
      return Left(ShatajPayError('Network error: ${e.toString()}'));
    }
  }

  Future<Map<String, dynamic>> initiatePayment(
    double amount,
    String currency,
  ) async {
    final url = Uri.parse('$_baseUrl/payment/initiate');

    try {
      final response = await http
          .post(
            url,
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $apiKey',
            },
            body: jsonEncode({'amount': amount, 'currency': currency}),
          )
          .timeout(Duration(seconds: 15)); // Set a timeout

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw ShatajPayError(
          'Payment initiation failed. Status code: ${response.statusCode}',
        );
      }
    } catch (e) {
      throw ShatajPayError('Network error: ${e.toString()}');
    }
  }

  Future<Either<ShatajPayError, TokenResponseModel>> createToken() async {
    final headers = {
      "accept": 'application/json',
      "username": shatajPayCredentials.username,
      "password": shatajPayCredentials.password,
      'content-type': 'application/json',
    };
    final body = {
      "app_key": shatajPayCredentials.appKey,
      "app_secret": shatajPayCredentials.appSecret,
    };

    final data = await networkCallHelper(
      function:
          () => http.post(
            Uri.parse("$_baseUrl/tokenized/checkout/token/grant"),
            headers: headers,
            body: json.encode(body),
          ),
    );

    return data.fold(
      (l) => Left(l),
      (r) => Right(TokenResponseModel.fromMap(r)),
    );
  }

  Future<Either<ShatajPayError, CreateAgreementResponseModel>>
  payWithAgreement({
    required String idToken,
    required String amount,
    required String agreementId,
    required String merchantInvoiceNumber,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/checkout/payment'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $idToken',
        },
        body: jsonEncode({
          'amount': amount,
          'agreement_id': agreementId,
          'merchant_invoice_number': merchantInvoiceNumber,
        }),
      );

      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        return right(CreateAgreementResponseModel.fromJson(jsonResponse));
      } else {
        return left(ShatajPayError('Failed to create payment agreement.'));
      }
    } catch (e) {
      return left(ShatajPayError('Network error: ${e.toString()}'));
    }
  }

  Future<Either<ShatajPayError, PayWithAgreementExecuteResponseModel>>
  executePayWithAgreement({
    required String paymentId,
    required String idToken,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/checkout/execute'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $idToken',
        },
        body: jsonEncode({'payment_id': paymentId}),
      );

      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        return right(
          PayWithAgreementExecuteResponseModel.fromJson(jsonResponse),
        );
      } else {
        return left(ShatajPayError('Payment execution failed.'));
      }
    } catch (e) {
      return left(ShatajPayError('Network error: ${e.toString()}'));
    }
  }
}
